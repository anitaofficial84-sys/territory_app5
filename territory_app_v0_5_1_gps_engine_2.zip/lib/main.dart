import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'activity_model.dart';
import 'gps_engine.dart';
import 'hex_grid.dart';
import 'home_screen.dart';

const _cellsKey = 'territory_hex_cells';
const _activitiesKey = 'territory_activities_v2';
const _coinsKey = 'territory_coins';
const _xpKey = 'territory_king_xp';
const _carryKey = 'territory_coin_carry_m';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TerritoryApp());
}

class TerritoryApp extends StatelessWidget {
  const TerritoryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TERRITORY',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF12A150),
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F5F7),
      ),
      home: const RootShell(),
    );
  }
}

ThemeData _dark() {
  return ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF090D12),
    colorScheme: const ColorScheme.dark(
      primary: Color(0xFFB8F36B),
      secondary: Color(0xFF72D6C5),
      surface: Color(0xFF121922),
    ),
    useMaterial3: true,
  );
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _tab = 0;
  final _tracker = GlobalKey<TrackerScreenState>();
  int _homeVersion = 0;

  void _record() {
    setState(() => _tab = 1);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _tracker.currentState?.startRecording();
    });
  }

  void _select(int index) {
    if (index == 2) {
      _record();
      return;
    }
    setState(() {
      _tab = index;
      if (index == 0) _homeVersion++;
    });
  }

  void _openActivity(Activity activity) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ActivityDetailScreen(activity: activity),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          HomeScreen(
            key: ValueKey(_homeVersion),
            onRecord: _record,
            onOpenMap: () => setState(() => _tab = 1),
            onOpenActivity: _openActivity,
          ),
          Theme(
            data: _dark(),
            child: TrackerScreen(key: _tracker),
          ),
          const SizedBox.shrink(),
          const _Soon('Groups', Icons.groups),
          const ProfileScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: _select,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.map_outlined),
            selectedIcon: Icon(Icons.map),
            label: 'Maps',
          ),
          NavigationDestination(
            icon: Icon(Icons.radio_button_checked),
            label: 'Record',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            selectedIcon: Icon(Icons.groups),
            label: 'Groups',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'You',
          ),
        ],
      ),
    );
  }
}

class _Soon extends StatelessWidget {
  const _Soon(this.title, this.icon);

  final String title;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Colors.grey),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
            const Text(
              'Coming soon',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class TrackerScreen extends StatefulWidget {
  const TrackerScreen({super.key});

  @override
  State<TrackerScreen> createState() => TrackerScreenState();
}

class TrackerScreenState extends State<TrackerScreen> {
  final MapController _map = MapController();
  final _route = <ActivityPoint>[];
  final _claimed = <String>{};
  final _gpsEngine = GpsEngine();

  StreamSubscription<Position>? _gps;
  List<Polygon> _polys = [];

  LatLng _center = const LatLng(28.4595, 77.0266);
  bool _recording = false;
  bool _paused = false;
  bool _mapReady = false;
  bool _loading = true;

  String _status = 'Getting location…';

  double _distanceKm = 0;
  double _lastAccuracy = 0;
  double _carryM = 0;
  double _elevationGain = 0;
  double? _filteredAltitude;
  double _maxSpeed = 0;

  DateTime? _started;
  DateTime? _activeSegmentStarted;

  // Elapsed recording time excludes time spent in the explicit pause state.
  int _activeElapsedSeconds = 0;

  int _movingSeconds = 0;
  int _rejected = 0;
  int _newCells = 0;
  int _coins = 0;
  int _xp = 0;
  int _awardedMovingMinutes = 0;

  String? _candidate;
  int _candidateHits = 0;

  @override
  void initState() {
    super.initState();
    _load();
    _locate();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    setState(() {
      _claimed.addAll(prefs.getStringList(_cellsKey) ?? const []);
      _carryM = prefs.getDouble(_carryKey) ?? 0;
      _coins = prefs.getInt(_coinsKey) ?? 0;
      _xp = prefs.getInt(_xpKey) ?? 0;
      _polys = _buildPolys();
      _loading = false;
    });
  }

  Future<void> _locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (mounted) setState(() => _status = 'Location is off');
      return;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      if (mounted) setState(() => _status = 'Location blocked');
      await Geolocator.openAppSettings();
      return;
    }

    if (permission == LocationPermission.denied) {
      if (mounted) setState(() => _status = 'Location permission required');
      return;
    }

    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (!mounted) return;

      setState(() {
        _center = LatLng(position.latitude, position.longitude);
        _lastAccuracy = position.accuracy;
        _status = 'Ready';
      });
      _move(_center, 16);
    } catch (_) {
      if (mounted) setState(() => _status = 'Could not get GPS fix');
    }
  }

  Future<void> startRecording() async {
    if (_recording) return;

    final permission = await Geolocator.checkPermission();
    if (permission != LocationPermission.always &&
        permission != LocationPermission.whileInUse) {
      await _locate();
      return;
    }

    setState(() {
      _recording = true;
      _paused = false;
      _started = DateTime.now();
      _activeSegmentStarted = _started;
      _activeElapsedSeconds = 0;
      _route.clear();
      _distanceKm = 0;
      _movingSeconds = 0;
      _elevationGain = 0;
      _filteredAltitude = null;
      _maxSpeed = 0;
      _newCells = 0;
      _rejected = 0;
      _candidate = null;
      _candidateHits = 0;
      _awardedMovingMinutes = 0;
      _gpsEngine.reset();
      _status = 'Recording activity';
    });

    _subscribe();
  }

  void _subscribe() {
    final LocationSettings settings =
        defaultTargetPlatform == TargetPlatform.android
            ? AndroidSettings(
                accuracy: LocationAccuracy.best,
                distanceFilter: 3,
                intervalDuration: const Duration(seconds: 1),
                foregroundNotificationConfig:
                    const ForegroundNotificationConfig(
                  notificationTitle: 'TERRITORY',
                  notificationText: 'Recording your activity',
                  notificationChannelName: 'Activity recording',
                  enableWakeLock: true,
                  setOngoing: true,
                ),
              )
            : const LocationSettings(
                accuracy: LocationAccuracy.best,
                distanceFilter: 3,
              );

    _gps = Geolocator.getPositionStream(locationSettings: settings).listen(
      _onPosition,
      onError: (_) => _setStatus('GPS stream interrupted'),
    );
  }

  void _setStatus(String value) {
    if (mounted) setState(() => _status = value);
  }

  Future<void> pauseRecording() async {
    if (!_recording || _paused) return;

    await _gps?.cancel();
    _gps = null;

    final now = DateTime.now();
    if (_activeSegmentStarted != null) {
      _activeElapsedSeconds += now.difference(_activeSegmentStarted!).inSeconds;
    }
    _activeSegmentStarted = null;

    if (mounted) {
      setState(() {
        _paused = true;
        _status = 'Paused';
      });
    }
  }

  void resumeRecording() {
    if (!_recording || !_paused) return;

    final now = DateTime.now();
    setState(() {
      _paused = false;
      _activeSegmentStarted = now;
      _status = 'Recording activity';
    });
    _subscribe();
  }

  Future<void> finishRecording() async {
    if (!_recording) return;

    await _gps?.cancel();
    _gps = null;

    if (_activeSegmentStarted != null) {
      _activeElapsedSeconds += DateTime.now().difference(_activeSegmentStarted!).inSeconds;
      _activeSegmentStarted = null;
    }

    final activity = _buildActivity();

    if (activity != null) {
      await _saveActivity(activity);
    }
    await _saveCells();
    await _saveProgress();

    if (!mounted) return;

    setState(() {
      _recording = false;
      _paused = false;
      _status = activity == null ? 'No activity saved' : 'Activity saved';
    });

    if (activity != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Activity saved to your phone')),
      );
    }
  }

  Activity? _buildActivity() {
    if (_route.length < 2) return null;

    final started = _started ?? DateTime.now();
    return Activity(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      sport: 'Run',
      started: started,
      ended: DateTime.now(),
      distanceKm: _distanceKm,
      elapsedSeconds: _activeElapsedSeconds,
      movingSeconds: _movingSeconds,
      elevationGainM: _elevationGain,
      maxSpeedKmh: _maxSpeed,
      newCells: _newCells,
      points: List.unmodifiable(_route),
    );
  }

  void _onPosition(Position position) {
    if (!mounted || !_recording || _paused) return;

    final result = _gpsEngine.process(position);
    if (!result.accepted) {
      if (mounted) setState(() => _rejected++);
      return;
    }

    final point = result.point!;
    final timestamp = result.timestamp!;

    if (result.distanceM > 0) {
      _distanceKm += result.distanceM / 1000.0;
      _movingSeconds += result.movingSeconds.round();
      _maxSpeed = math.max(_maxSpeed, result.speedMps * 3.6);

      _carryM += result.distanceM;
      final earnedCoins = (_carryM ~/ 100).toInt();
      if (earnedCoins > 0) {
        _carryM -= earnedCoins * 100;
        _coins += earnedCoins;
      }

      final movingMinutes = _movingSeconds ~/ 60;
      final newMinutes = movingMinutes - _awardedMovingMinutes;
      if (newMinutes > 0) {
        _xp += newMinutes;
        _awardedMovingMinutes = movingMinutes;
      }
    }

    if (result.altitudeM != null && result.altitudeM!.isFinite) {
      final rawAltitude = result.altitudeM!;
      final filtered = _filteredAltitude == null
          ? rawAltitude
          : _filteredAltitude! + (rawAltitude - _filteredAltitude!) * 0.20;

      if (_filteredAltitude != null) {
        final elevationDelta = filtered - _filteredAltitude!;
        if (elevationDelta >= 1.5) {
          _elevationGain += elevationDelta;
        }
      }
      _filteredAltitude = filtered;
    }

    // Keep a complete accepted GPS sample history, including stationary
    // samples. This makes the saved route more faithful without charging
    // distance for GPS jitter.
    _route.add(
      ActivityPoint(
        lat: point.latitude,
        lng: point.longitude,
        time: timestamp,
        accuracy: result.accuracyM!,
        altitude: result.altitudeM?.isFinite == true ? result.altitudeM! : 0,
      ),
    );

    final cell = HexGrid.keyFor(point);
    if (!_claimed.contains(cell)) {
      if (_candidate == cell) {
        _candidateHits++;
      } else {
        _candidate = cell;
        _candidateHits = 1;
      }

      if (_candidateHits >= 2) {
        _claimed.add(cell);
        _newCells++;
        _xp += 10;
        _candidate = null;
        _candidateHits = 0;
        _polys = _buildPolys();
        unawaited(_saveCells());
      }
    }

    setState(() {
      _center = point;
      _lastAccuracy = result.accuracyM!;
      _status = result.stationary
          ? 'Recording • standing still'
          : 'Recording • ${_route.length} GPS points';
    });

    unawaited(_saveProgress());
    _move(point, null);
  }

  Future<void> _saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_coinsKey, _coins);
    await prefs.setInt(_xpKey, _xp);
    await prefs.setDouble(_carryKey, _carryM);
  }

  Future<void> _saveCells() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_cellsKey, _claimed.toList());
  }

  Future<void> _saveActivity(Activity activity) async {
    final prefs = await SharedPreferences.getInstance();
    final activities = decodeActivities(
      prefs.getString(_activitiesKey),
    );
    activities.add(activity);
    await prefs.setString(
      _activitiesKey,
      encodeActivities(activities),
    );
  }

  void _move(LatLng point, double? zoom) {
    if (!_mapReady) return;

    try {
      _map.move(point, zoom ?? _map.camera.zoom);
    } catch (_) {
      // The map can briefly receive a move before its controller is ready.
    }
  }

  List<Polygon> _buildPolys() {
    return _claimed.map((key) {
      final points = HexGrid.boundary(key);
      if (points == null) return null;

      return Polygon(
        points: points,
        color: const Color(0x557ED957),
        borderColor: const Color(0xFFB8F36B),
        borderStrokeWidth: 1,
      );
    }).whereType<Polygon>().toList();
  }

  @override
  void dispose() {
    _gps?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: _center,
                initialZoom: 15,
                onMapReady: () {
                  _mapReady = true;
                },
              ),
              children: [
                TileLayer(
                  urlTemplate:
                      'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.territory.app',
                ),
                PolygonLayer(polygons: _polys),
                if (_route.length > 1)
                  PolylineLayer(
                    polylines: [
                      Polyline(
                        points: _route.map((e) => e.latLng).toList(),
                        strokeWidth: 5,
                        color: const Color(0xFFB8F36B),
                      ),
                    ],
                  ),
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _center,
                      width: 20,
                      height: 20,
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFFB8F36B),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white,
                            width: 3,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                RichAttributionWidget(
                  attributions: [
                    TextSourceAttribution('© OpenStreetMap contributors'),
                  ],
                ),
              ],
            ),
            Positioned(
              left: 16,
              right: 16,
              top: 14,
              child: _top(),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 16,
              child: _bottom(),
            ),
            if (_loading)
              const Center(child: CircularProgressIndicator()),
          ],
        ),
      ),
    );
  }

  Widget _top() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xEE0B1118),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'TERRITORY',
            style: TextStyle(
              letterSpacing: 3,
              fontWeight: FontWeight.w900,
              color: Color(0xFFB8F36B),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _stat('TERRITORY', '${_claimed.length} cells'),
              const SizedBox(width: 18),
              _stat(
                'DISTANCE',
                '${_distanceKm.toStringAsFixed(2)} km',
              ),
              const Spacer(),
              _stat('XP', '$_xp'),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: _distanceKm <= 0 ? 0 : (_distanceKm * 10) % 1,
            minHeight: 6,
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            color: Colors.white54,
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }

  Widget _bottom() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xF20B1118),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                _recording
                    ? Icons.radio_button_checked
                    : Icons.gps_fixed,
                color: _recording
                    ? Colors.redAccent
                    : const Color(0xFFB8F36B),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _status,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                '${_lastAccuracy.toStringAsFixed(0)}m',
                style: const TextStyle(color: Colors.white54),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (_recording)
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed:
                        _paused ? resumeRecording : pauseRecording,
                    icon: Icon(
                      _paused ? Icons.play_arrow : Icons.pause,
                    ),
                    label: Text(_paused ? 'RESUME' : 'PAUSE'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFFF8A00),
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: finishRecording,
                    icon: const Icon(Icons.stop),
                    label: const Text('FINISH'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFB84242),
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            )
          else
            FilledButton.icon(
              onPressed: startRecording,
              icon: const Icon(Icons.play_arrow),
              label: const Text('START RUN'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFB8F36B),
                foregroundColor: const Color(0xFF10160C),
              ),
            ),
          const SizedBox(height: 5),
          Text(
            'GPS ≤30m • route saved locally • ${_route.length} points',
            style: const TextStyle(
              color: Colors.white38,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}

class ActivityDetailScreen extends StatelessWidget {
  const ActivityDetailScreen({super.key, required this.activity});

  final Activity activity;

  String _duration(int seconds) {
    return '${(seconds ~/ 3600).toString().padLeft(2, '0')}:'
        '${((seconds % 3600) ~/ 60).toString().padLeft(2, '0')}:'
        '${(seconds % 60).toString().padLeft(2, '0')}';
  }

  String _pace() {
    final minutes = activity.avgPaceMinPerKm;
    if (minutes <= 0) return '--:--';

    final whole = minutes.floor();
    final seconds = ((minutes - whole) * 60).round();

    return '$whole:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: _dark(),
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            '${activity.sport} • '
            '${activity.distanceKm.toStringAsFixed(2)} km',
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              height: 260,
              decoration: BoxDecoration(
                color: const Color(0xFF121922),
                borderRadius: BorderRadius.circular(20),
              ),
              child: activity.points.length < 2
                  ? const Center(child: Text('No route'))
                  : FlutterMap(
                      options: MapOptions(
                        initialCenter:
                            activity.points[activity.points.length ~/ 2]
                                .latLng,
                        initialZoom: 15,
                        interactionOptions:
                            const InteractionOptions(
                          flags: InteractiveFlag.all,
                        ),
                      ),
                      children: [
                        TileLayer(
                          urlTemplate:
                              'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'com.territory.app',
                        ),
                        PolylineLayer(
                          polylines: [
                            Polyline(
                              points: activity.points
                                  .map((p) => p.latLng)
                                  .toList(),
                              strokeWidth: 5,
                              color: const Color(0xFFB8F36B),
                            ),
                          ],
                        ),
                      ],
                    ),
            ),
            const SizedBox(height: 12),
            _grid([
              _metric(
                'Distance',
                '${activity.distanceKm.toStringAsFixed(2)} km',
              ),
              _metric('Pace', '${_pace()}/km'),
              _metric(
                'Moving time',
                _duration(activity.movingSeconds),
              ),
              _metric(
                'Elapsed',
                _duration(activity.elapsedSeconds),
              ),
              _metric(
                'Avg speed',
                '${activity.avgSpeedKmh.toStringAsFixed(1)} km/h',
              ),
              _metric(
                'Max speed',
                '${activity.maxSpeedKmh.toStringAsFixed(1)} km/h',
              ),
              _metric(
                'Elevation',
                '${activity.elevationGainM.round()} m',
              ),
              _metric(
                'Territory',
                '+${activity.newCells} cells',
              ),
            ]),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                title: const Text('Route points'),
                trailing: Text('${activity.points.length}'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _grid(List<Widget> items) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 2.5,
      children: items,
    );
  }

  Widget _metric(String label, String value) {
    return Card(
      color: const Color(0xFF121922),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: Colors.white54,
                fontSize: 11,
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List<Activity> _activities = [];
  int _cells = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    setState(() {
      _activities = decodeActivities(
        prefs.getString(_activitiesKey),
      );
      _cells = (prefs.getStringList(_cellsKey) ?? const []).length;
    });
  }

  double get _totalKm =>
      _activities.fold(0.0, (sum, item) => sum + item.distanceKm);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('You')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const CircleAvatar(
              radius: 34,
              child: Icon(Icons.person, size: 36),
            ),
            const SizedBox(height: 12),
            const Center(
              child: Text(
                'Territory Runner',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    _value('Activities', '${_activities.length}'),
                    _value(
                      'Distance',
                      '${_totalKm.toStringAsFixed(1)} km',
                    ),
                    _value('Territory', '$_cells'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _value(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            label,
            style: const TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
