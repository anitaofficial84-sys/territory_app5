import 'dart:math' as math;

import 'package:latlong2/latlong.dart';

/// Real hexagonal grid (pointy-top, axial coordinates) on a Web-Mercator plane.
///
/// This replaces the old square-grid approximation. It is NOT Uber H3, but it
/// gives true hexagons that tile without gaps. All grid access goes through
/// [keyFor] and [boundary], so H3 can be swapped in later without touching UI.
///
/// [edge] is in Mercator metres. Ground size shrinks with cos(latitude):
/// about 96 m at 29 degrees N (Hisar), 110 m at the equator.
class HexGrid {
  HexGrid._();

  static const double edge = 110.0;
  static const double _earth = 6378137.0;
  static const double _maxLat = 85.0;
  static final double _sqrt3 = math.sqrt(3);

  static double _toX(double lng) => _earth * lng * math.pi / 180;

  static double _toY(double lat) {
    final clamped = lat.clamp(-_maxLat, _maxLat).toDouble();
    return _earth * math.log(math.tan(math.pi / 4 + clamped * math.pi / 360));
  }

  static double _toLng(double x) => x / _earth * 180 / math.pi;

  static double _toLat(double y) =>
      (2 * math.atan(math.exp(y / _earth)) - math.pi / 2) * 180 / math.pi;

  /// Cell id for a position, formatted "q:r".
  static String keyFor(LatLng p) {
    final x = _toX(p.longitude);
    final y = _toY(p.latitude);
    final q = (_sqrt3 / 3 * x - y / 3) / edge;
    final r = (2 / 3 * y) / edge;
    final s = -q - r;
    var rq = q.round();
    var rr = r.round();
    final rs = s.round();
    final dq = (rq - q).abs();
    final dr = (rr - r).abs();
    final ds = (rs - s).abs();
    if (dq > dr && dq > ds) {
      rq = -rr - rs;
    } else if (dr > ds) {
      rr = -rq - rs;
    }
    return '$rq:$rr';
  }

  /// Centre of a cell, or null if [key] is invalid.
  static LatLng? center(String key) {
    final qr = _parse(key);
    if (qr == null) return null;
    final x = edge * (_sqrt3 * qr.$1 + _sqrt3 / 2 * qr.$2);
    final y = edge * (1.5 * qr.$2);
    return LatLng(_toLat(y), _toLng(x));
  }

  /// The six corners of a cell, or null if [key] is invalid.
  static List<LatLng>? boundary(String key) {
    final qr = _parse(key);
    if (qr == null) return null;
    final cx = edge * (_sqrt3 * qr.$1 + _sqrt3 / 2 * qr.$2);
    final cy = edge * (1.5 * qr.$2);
    final corners = <LatLng>[];
    for (var i = 0; i < 6; i++) {
      final angle = math.pi / 180 * (60 * i - 30);
      corners.add(LatLng(
        _toLat(cy + edge * math.sin(angle)),
        _toLng(cx + edge * math.cos(angle)),
      ));
    }
    return corners;
  }

  static (int, int)? _parse(String key) {
    final parts = key.split(':');
    if (parts.length != 2) return null;
    final q = int.tryParse(parts[0]);
    final r = int.tryParse(parts[1]);
    if (q == null || r == null) return null;
    return (q, r);
  }
}
