import 'dart:math' as math;

/// Simple Kalman-style smoother for GPS fixes.
///
/// Trusts fixes with small reported accuracy more, and fixes with large
/// accuracy less, so a standing/jittering phone does not zigzag the route.
class GpsSmoother {
  GpsSmoother({this.processNoiseMps = 3.0});

  /// How fast (m/s) we assume the person can change position between fixes.
  final double processNoiseMps;

  double? _lat;
  double? _lng;
  double _variance = -1; // metres squared; < 0 means "not initialised"
  int _lastMs = 0;

  void reset() {
    _lat = null;
    _lng = null;
    _variance = -1;
    _lastMs = 0;
  }

  /// Feeds one raw fix and returns the smoothed (lat, lng).
  (double, double) update(
      double lat, double lng, double accuracyM, DateTime time) {
    final acc = math.max(accuracyM, 1.0);
    final ms = time.millisecondsSinceEpoch;
    if (_lat == null || _lng == null || _variance < 0) {
      _lat = lat;
      _lng = lng;
      _variance = acc * acc;
      _lastMs = ms;
      return (lat, lng);
    }
    final dtMs = ms - _lastMs;
    if (dtMs > 0) {
      final dt = dtMs / 1000.0;
      _variance += dt * processNoiseMps * processNoiseMps;
      _lastMs = ms;
    }
    final k = _variance / (_variance + acc * acc);
    _lat = _lat! + k * (lat - _lat!);
    _lng = _lng! + k * (lng - _lng!);
    _variance = (1 - k) * _variance;
    return (_lat!, _lng!);
  }
}
