import 'dart:math' as math;

import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

/// Production-oriented GPS processing for activity recording.
///
/// Responsibilities:
/// - rejects unusable/obviously impossible fixes
/// - smooths coordinates using reported horizontal accuracy
/// - protects against long callback gaps and GPS teleportation
/// - keeps distance and moving-time accounting separate
/// - detects small stationary jitter
class GpsEngine {
  GpsEngine({this.maxRunningSpeedMps = 12.0}) : _smoother = _AccuracySmoother();

  final double maxRunningSpeedMps;
  final _AccuracySmoother _smoother;
  final Distance _distance = const Distance();

  DateTime? _lastAcceptedTime;
  LatLng? _lastAcceptedPoint;
  double _maxSpeedMps = 0;

  void reset() {
    _smoother.reset();
    _lastAcceptedTime = null;
    _lastAcceptedPoint = null;
    _maxSpeedMps = 0;
  }

  double get maxSpeedMps => _maxSpeedMps;

  GpsResult process(Position p) {
    if (!p.latitude.isFinite || !p.longitude.isFinite) {
      return const GpsResult.reject(GpsRejectReason.invalid);
    }
    if (!p.accuracy.isFinite || p.accuracy <= 0 || p.accuracy > 50) {
      return const GpsResult.reject(GpsRejectReason.poorAccuracy);
    }

    final time = p.timestamp;
    final point = _smoother.update(
      p.latitude,
      p.longitude,
      p.accuracy,
      time,
    );

    if (_lastAcceptedPoint == null || _lastAcceptedTime == null) {
      _lastAcceptedPoint = point;
      _lastAcceptedTime = time;
      return GpsResult.accept(
        point: point,
        timestamp: time,
        accuracyM: p.accuracy,
        altitudeM: p.altitude,
        distanceM: 0,
        movingSeconds: 0,
        speedMps: 0,
        stationary: false,
      );
    }

    final rawSeconds = time.difference(_lastAcceptedTime!).inMilliseconds / 1000.0;
    if (rawSeconds <= 0) {
      return const GpsResult.reject(GpsRejectReason.oldTimestamp);
    }

    final distanceM = _distance.as(LengthUnit.Meter, _lastAcceptedPoint!, point);
    final speedMps = distanceM / rawSeconds;
    final maxAllowed = math.max(
      maxRunningSpeedMps,
      // GPS error can look like a short burst. Give higher-accuracy fixes a
      // little more room, but never allow an extreme teleport.
      8.0 + (p.accuracy * 0.5),
    );

    if (speedMps > maxAllowed || distanceM > 150.0) {
      return GpsResult.reject(
        GpsRejectReason.teleport,
        point: point,
        timestamp: time,
        accuracyM: p.accuracy,
      );
    }

    // Distance below this threshold is treated as GPS jitter. The timestamp
    // still advances so a later fix is measured from the latest valid sample.
    final jitterM = math.max(2.0, math.min(6.0, p.accuracy * 0.35));
    final stationary = distanceM < jitterM;

    // Only a bounded amount of time is credited per callback. This protects
    // moving-time from a delayed Android location callback.
    final creditedSeconds = stationary ? 0.0 : math.min(rawSeconds, 5.0);

    _lastAcceptedTime = time;
    if (!stationary) {
      _lastAcceptedPoint = point;
      _maxSpeedMps = math.max(_maxSpeedMps, speedMps);
    }

    return GpsResult.accept(
      point: point,
      timestamp: time,
      accuracyM: p.accuracy,
      altitudeM: p.altitude,
      distanceM: stationary ? 0 : distanceM,
      movingSeconds: creditedSeconds,
      speedMps: stationary ? 0 : speedMps,
      stationary: stationary,
    );
  }
}

class GpsResult {
  const GpsResult._({
    required this.accepted,
    this.reason,
    this.point,
    this.timestamp,
    this.accuracyM,
    this.altitudeM,
    this.distanceM = 0,
    this.movingSeconds = 0,
    this.speedMps = 0,
    this.stationary = false,
  });

  const GpsResult.reject(GpsRejectReason reason,
      {LatLng? point, DateTime? timestamp, double? accuracyM})
      : this._(
          accepted: false,
          reason: reason,
          point: point,
          timestamp: timestamp,
          accuracyM: accuracyM,
        );

  factory GpsResult.accept({
    required LatLng point,
    required DateTime timestamp,
    required double accuracyM,
    required double altitudeM,
    required double distanceM,
    required double movingSeconds,
    required double speedMps,
    required bool stationary,
  }) => GpsResult._(
        accepted: true,
        point: point,
        timestamp: timestamp,
        accuracyM: accuracyM,
        altitudeM: altitudeM,
        distanceM: distanceM,
        movingSeconds: movingSeconds,
        speedMps: speedMps,
        stationary: stationary,
      );

  final bool accepted;
  final GpsRejectReason? reason;
  final LatLng? point;
  final DateTime? timestamp;
  final double? accuracyM;
  final double? altitudeM;
  final double distanceM;
  final double movingSeconds;
  final double speedMps;
  final bool stationary;
}

enum GpsRejectReason { invalid, poorAccuracy, oldTimestamp, teleport }

class _AccuracySmoother {
  double? _lat;
  double? _lng;
  double _variance = -1;
  int _lastMs = 0;

  void reset() {
    _lat = null;
    _lng = null;
    _variance = -1;
    _lastMs = 0;
  }

  LatLng update(double lat, double lng, double accuracyM, DateTime time) {
    final acc = math.max(accuracyM, 1.0);
    final ms = time.millisecondsSinceEpoch;
    if (_lat == null || _lng == null || _variance < 0) {
      _lat = lat;
      _lng = lng;
      _variance = acc * acc;
      _lastMs = ms;
      return LatLng(lat, lng);
    }

    final dtMs = ms - _lastMs;
    if (dtMs > 0) {
      final dt = dtMs / 1000.0;
      _variance += dt * 3.0 * 3.0;
      _lastMs = ms;
    }

    final k = _variance / (_variance + acc * acc);
    _lat = _lat! + k * (lat - _lat!);
    _lng = _lng! + k * (lng - _lng!);
    _variance = (1 - k) * _variance;
    return LatLng(_lat!, _lng!);
  }
}
