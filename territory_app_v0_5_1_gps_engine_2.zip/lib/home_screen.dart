import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'activity_model.dart';

const _green = Color(0xFF12A150);
const _ink = Color(0xFF14191F);
const _muted = Color(0xFF6B7280);
const _activitiesKey = 'territory_activities_v2';
const _cellsKey = 'territory_hex_cells';
const _coinsKey = 'territory_coins';
const _xpKey = 'territory_king_xp';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.onRecord,
    required this.onOpenMap,
    required this.onOpenActivity,
  });

  final VoidCallback onRecord;
  final VoidCallback onOpenMap;
  final void Function(Activity) onOpenActivity;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Activity> _activities = [];
  int _cells = 0;
  int _coins = 0;
  int _xp = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    setState(() {
      _activities = decodeActivities(prefs.getString(_activitiesKey));
      _cells = (prefs.getStringList(_cellsKey) ?? const []).length;
      _coins = prefs.getInt(_coinsKey) ?? 0;
      _xp = prefs.getInt(_xpKey) ?? 0;
    });
  }

  double get totalKm =>
      _activities.fold(0.0, (sum, activity) => sum + activity.distanceKm);

  int get totalMoving =>
      _activities.fold(0, (sum, activity) => sum + activity.movingSeconds);

  int get streak {
    if (_activities.isEmpty) return 0;

    final days = _activities
        .map((a) => DateTime(
              a.started.year,
              a.started.month,
              a.started.day,
            ))
        .toSet()
        .toList()
      ..sort((a, b) => b.compareTo(a));

    var count = 1;
    for (var i = 1; i < days.length; i++) {
      final gap = days[i - 1].difference(days[i]).inDays;
      if (gap != 1) break;
      count++;
    }
    return count;
  }

  String _pace(double minutesPerKm) {
    if (minutesPerKm <= 0) return '--:--';

    final whole = minutesPerKm.floor();
    final seconds = ((minutesPerKm - whole) * 60).round();

    return '${whole.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  String _duration(int seconds) {
    return '${(seconds ~/ 3600).toString().padLeft(2, '0')}:'
        '${((seconds % 3600) ~/ 60).toString().padLeft(2, '0')}:'
        '${(seconds % 60).toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F5F7),
      appBar: AppBar(
        title: const Text(
          'TERRITORY',
          style: TextStyle(
            letterSpacing: 3,
            fontWeight: FontWeight.w900,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
          children: [
            _hero(),
            const SizedBox(height: 12),
            _stats(),
            const SizedBox(height: 12),
            _recent(),
          ],
        ),
      ),
    );
  }

  Widget _hero() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _ink,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Your training',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 5),
          Text(
            '${totalKm.toStringAsFixed(2)} km',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 34,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            '${_activities.length} activities  •  '
            '${_duration(totalMoving)} moving time',
            style: const TextStyle(color: Colors.white60),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: widget.onRecord,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Record activity'),
                  style: FilledButton.styleFrom(
                    backgroundColor: _green,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                onPressed: widget.onOpenMap,
                tooltip: 'Open map',
                icon: const Icon(
                  Icons.map_outlined,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stats() {
    return Card(
      color: Colors.white,
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 3.2,
          children: [
            _metric('Activities', '${_activities.length}'),
            _metric('Streak', '$streak days'),
            _metric('Territory', '$_cells'),
            _metric('Coins', '$_coins'),
            _metric('King XP', '$_xp'),
          ],
        ),
      ),
    );
  }

  Widget _metric(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 10,
              color: _muted,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: _ink,
            ),
          ),
        ],
      ),
    );
  }

  Widget _recent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            'Recent activities',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        if (_activities.isEmpty)
          const Card(
            elevation: 0,
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                'No activities yet. Your completed runs will appear here.',
              ),
            ),
          ),
        ..._activities.reversed.take(10).map(
          (activity) => Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              onTap: () => widget.onOpenActivity(activity),
              leading: const CircleAvatar(
                backgroundColor: Color(0xFFE8F5EC),
                child: Icon(
                  Icons.directions_run,
                  color: _green,
                ),
              ),
              title: Text(
                '${activity.distanceKm.toStringAsFixed(2)} km '
                '${activity.sport}',
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                ),
              ),
              subtitle: Text(
                '${_pace(activity.avgPaceMinPerKm)}/km  •  '
                '${_duration(activity.movingSeconds)}  •  '
                '${activity.elevationGainM.round()} m',
              ),
              trailing: const Icon(Icons.chevron_right),
            ),
          ),
        ),
      ],
    );
  }
}
